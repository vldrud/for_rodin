# Presidental elections in Ukraine in 2019

## Plan of analyzis

1. Import libraries
2. Import dataset
3. Data Processing and filtration
4. Test for normality 
5. Vizualization the data and finding the problems

### Import libraries


```python
import os
import csv
import openpyxl

from openpyxl import load_workbook

import numpy as np
import pandas as pd
import swifter 

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

from threading import Thread
import seaborn as sns

import scipy.stats as stats

from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, log_loss
```

### Import the data

Data contains two files: protokols and results
  Protokols - information about how many people visited election station and voted 
  Results - information about how many people voted for each candidate 


```python
print(open('ElectionProtocols.csv'))

protokols_df = pd.read_csv('ElectionProtocols.csv', sep='\t')

protokols_df
```

    <_io.TextIOWrapper name='ElectionProtocols.csv' mode='r' encoding='cp1251'>
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>election_name</th>
      <th>election_type</th>
      <th>election_date</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>city_rayon</th>
      <th>koatuu</th>
      <th>district_no</th>
      <th>district_desc</th>
      <th>...</th>
      <th>voted_home</th>
      <th>voted_home_percent</th>
      <th>voted_total</th>
      <th>voted_total_percent</th>
      <th>ballots_invalid</th>
      <th>ballots_invalid_percent</th>
      <th>votes_candidates</th>
      <th>votes_againstall</th>
      <th>votes_againstall_percent</th>
      <th>approval_dt</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1121</td>
      <td>66,48</td>
      <td>20</td>
      <td>1,78</td>
      <td>1101</td>
      <td>0</td>
      <td>0</td>
      <td>01.04.2019 01:30</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1358</td>
      <td>64,39</td>
      <td>17</td>
      <td>1,25</td>
      <td>1341</td>
      <td>0</td>
      <td>0</td>
      <td>01.04.2019 00:50</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>841</td>
      <td>65,6</td>
      <td>12</td>
      <td>1,42</td>
      <td>822</td>
      <td>0</td>
      <td>0</td>
      <td>02.04.2019 23:45</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1594</td>
      <td>65,48</td>
      <td>12</td>
      <td>0,75</td>
      <td>1583</td>
      <td>0</td>
      <td>0</td>
      <td>01.04.2019 19:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>140</td>
      <td>62,22</td>
      <td>0</td>
      <td>0</td>
      <td>140</td>
      <td>0</td>
      <td>0</td>
      <td>01.04.2019 00:10</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>29984</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000380</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>549</td>
      <td>13,02</td>
      <td>9</td>
      <td>1,63</td>
      <td>540</td>
      <td>0</td>
      <td>0</td>
      <td>01.04.2019 01:40</td>
    </tr>
    <tr>
      <th>29985</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000276</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1441</td>
      <td>6,79</td>
      <td>7</td>
      <td>0,48</td>
      <td>1434</td>
      <td>0</td>
      <td>0</td>
      <td>01.04.2019 01:20</td>
    </tr>
    <tr>
      <th>29986</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000152</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59</td>
      <td>64,83</td>
      <td>0</td>
      <td>0</td>
      <td>59</td>
      <td>0</td>
      <td>0</td>
      <td>31.03.2019 20:32</td>
    </tr>
    <tr>
      <th>29987</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000792</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>122</td>
      <td>77,21</td>
      <td>0</td>
      <td>0</td>
      <td>122</td>
      <td>0</td>
      <td>0</td>
      <td>31.03.2019 22:40</td>
    </tr>
    <tr>
      <th>29988</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26,27</td>
      <td>0</td>
      <td>0</td>
      <td>232</td>
      <td>0</td>
      <td>0</td>
      <td>31.03.2019 22:05</td>
    </tr>
  </tbody>
</table>
<p>29989 rows × 34 columns</p>
</div>




```python
protokols_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 29989 entries, 0 to 29988
    Data columns (total 34 columns):
     #   Column                         Non-Null Count  Dtype  
    ---  ------                         --------------  -----  
     0   election_name                  29989 non-null  object 
     1   election_type                  29989 non-null  object 
     2   election_date                  29989 non-null  object 
     3   region                         29989 non-null  object 
     4   rayon                          28782 non-null  object 
     5   community                      29888 non-null  object 
     6   city_rayon                     4999 non-null   object 
     7   koatuu                         29989 non-null  int64  
     8   district_no                    29989 non-null  int64  
     9   district_desc                  29989 non-null  object 
     10  precinct_no                    29989 non-null  int64  
     11  precinct_desc                  29909 non-null  object 
     12  ballots_amount                 29989 non-null  int64  
     13  ballots_unused                 29989 non-null  int64  
     14  voters_amount                  29989 non-null  int64  
     15  voters_home                    29989 non-null  int64  
     16  ballots_received_precinct      29989 non-null  int64  
     17  ballots_false                  29989 non-null  int64  
     18  ballots_false_percent          29989 non-null  object 
     19  ballots_received_home          29989 non-null  int64  
     20  ballots_received_home_percent  29989 non-null  object 
     21  ballots_received_total         29989 non-null  int64  
     22  ballots_spoiled                0 non-null      float64
     23  voted_precinct                 0 non-null      float64
     24  voted_home                     0 non-null      float64
     25  voted_home_percent             0 non-null      float64
     26  voted_total                    29989 non-null  int64  
     27  voted_total_percent            29989 non-null  object 
     28  ballots_invalid                29989 non-null  int64  
     29  ballots_invalid_percent        29989 non-null  object 
     30  votes_candidates               29989 non-null  int64  
     31  votes_againstall               29989 non-null  int64  
     32  votes_againstall_percent       29989 non-null  int64  
     33  approval_dt                    29989 non-null  object 
    dtypes: float64(4), int64(16), object(14)
    memory usage: 7.8+ MB
    


```python
protokols_df['voted_total_percent'] = protokols_df['voted_total_percent'].apply(lambda x: float(x.replace(',', '.')))

protokols_df['voted_total_percent']
```




    0        66.48
    1        64.39
    2        65.60
    3        65.48
    4        62.22
             ...  
    29984    13.02
    29985     6.79
    29986    64.83
    29987    77.21
    29988    26.27
    Name: voted_total_percent, Length: 29989, dtype: float64




```python
print(open('ElectionResults.csv'))

results_df = pd.read_csv('ElectionResults.csv', sep='\t')

results_df
```

    <_io.TextIOWrapper name='ElectionResults.csv' mode='r' encoding='cp1251'>
    

    d:\pyth3_8_5\lib\site-packages\IPython\core\interactiveshell.py:3145: DtypeWarning: Columns (4,6) have mixed types.Specify dtype option on import or set low_memory=False.
      has_raised = await self.run_ast_nodes(code_ast.body, cell_name,
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>election_name</th>
      <th>election_type</th>
      <th>election_date</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>city_rayon</th>
      <th>koatuu</th>
      <th>district_no</th>
      <th>district_desc</th>
      <th>precinct_no</th>
      <th>precinct_desc</th>
      <th>candidate</th>
      <th>party</th>
      <th>partisan</th>
      <th>vote_count</th>
      <th>vote_percent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>50130</td>
      <td>смт Стрижавка – вул.Байдукова, вул.Бугова, вул...</td>
      <td>Балашов Геннадій Вікторович</td>
      <td>Партія "5.10"</td>
      <td>Партія "5.10"</td>
      <td>3</td>
      <td>0,26</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>50130</td>
      <td>смт Стрижавка – вул.Байдукова, вул.Бугова, вул...</td>
      <td>Безсмертний Роман Петрович</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>2</td>
      <td>0,17</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>50130</td>
      <td>смт Стрижавка – вул.Байдукова, вул.Бугова, вул...</td>
      <td>Богомолець Ольга Вадимівна</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>2</td>
      <td>0,17</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>50130</td>
      <td>смт Стрижавка – вул.Байдукова, вул.Бугова, вул...</td>
      <td>Богословська Інна Германівна</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>NaN</td>
      <td>520655900</td>
      <td>11</td>
      <td>Центр: місто Вінниця. ТВО включає: частина міс...</td>
      <td>50130</td>
      <td>смт Стрижавка – вул.Байдукова, вул.Бугова, вул...</td>
      <td>Бойко Юрій Анатолійович</td>
      <td>Самовисування</td>
      <td>Опозиційний блок</td>
      <td>32</td>
      <td>2,85</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1169566</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>900125</td>
      <td>Канада (провінції: Альберта, Британська Колумб...</td>
      <td>Тарута Сергій Олексійович</td>
      <td>Основа</td>
      <td>Основа</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169567</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>900125</td>
      <td>Канада (провінції: Альберта, Британська Колумб...</td>
      <td>Тимошенко Юлія Володимирівна</td>
      <td>Батьківщина</td>
      <td>Батьківщина</td>
      <td>10</td>
      <td>4,31</td>
    </tr>
    <tr>
      <th>1169568</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>900125</td>
      <td>Канада (провінції: Альберта, Британська Колумб...</td>
      <td>Тимошенко Юрій Володимирович</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169569</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>900125</td>
      <td>Канада (провінції: Альберта, Британська Колумб...</td>
      <td>Шевченко Ігор Анатолійович</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169570</th>
      <td>Вибори Президента України 2019</td>
      <td>Чергові</td>
      <td>31.03.2019</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>Закордонний виборчий округ</td>
      <td>900125</td>
      <td>Канада (провінції: Альберта, Британська Колумб...</td>
      <td>Шевченко Олександр Леонідович</td>
      <td>УКРОП</td>
      <td>УКРОП</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>1169571 rows × 17 columns</p>
</div>



#### Information about data


```python
results_df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>koatuu</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1.169571e+06</td>
      <td>1.169571e+06</td>
      <td>1.169571e+06</td>
      <td>1.169571e+06</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>4.293127e+09</td>
      <td>1.205495e+02</td>
      <td>4.263421e+05</td>
      <td>1.596240e+01</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.316895e+09</td>
      <td>6.121904e+01</td>
      <td>2.328696e+05</td>
      <td>5.637879e+01</td>
    </tr>
    <tr>
      <th>min</th>
      <td>5.101000e+08</td>
      <td>1.100000e+01</td>
      <td>1.000000e+00</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.121287e+09</td>
      <td>7.000000e+01</td>
      <td>2.102100e+05</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>4.625385e+09</td>
      <td>1.260000e+02</td>
      <td>4.619120e+05</td>
      <td>0.000000e+00</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>6.310138e+09</td>
      <td>1.730000e+02</td>
      <td>6.304410e+05</td>
      <td>3.000000e+00</td>
    </tr>
    <tr>
      <th>max</th>
      <td>9.000001e+09</td>
      <td>2.260000e+02</td>
      <td>9.001250e+05</td>
      <td>1.520000e+03</td>
    </tr>
  </tbody>
</table>
</div>




```python
results_df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1169571 entries, 0 to 1169570
    Data columns (total 17 columns):
     #   Column         Non-Null Count    Dtype 
    ---  ------         --------------    ----- 
     0   election_name  1169571 non-null  object
     1   election_type  1169571 non-null  object
     2   election_date  1169571 non-null  object
     3   region         1169571 non-null  object
     4   rayon          1122498 non-null  object
     5   community      1165632 non-null  object
     6   city_rayon     194961 non-null   object
     7   koatuu         1169571 non-null  int64 
     8   district_no    1169571 non-null  int64 
     9   district_desc  1169571 non-null  object
     10  precinct_no    1169571 non-null  int64 
     11  precinct_desc  1166451 non-null  object
     12  candidate      1169571 non-null  object
     13  party          1169571 non-null  object
     14  partisan       1169571 non-null  object
     15  vote_count     1169571 non-null  int64 
     16  vote_percent   1169571 non-null  object
    dtypes: int64(4), object(13)
    memory usage: 151.7+ MB
    


```python
# dropping the extra information
results_df = results_df.drop(columns=['election_name', 
                                      'election_type', 
                                      'election_date', 
                                      'city_rayon',
                                      'district_desc',
                                      'precinct_desc'])
```


```python
results_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>koatuu</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>candidate</th>
      <th>party</th>
      <th>partisan</th>
      <th>vote_count</th>
      <th>vote_percent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>520655900</td>
      <td>11</td>
      <td>50130</td>
      <td>Балашов Геннадій Вікторович</td>
      <td>Партія "5.10"</td>
      <td>Партія "5.10"</td>
      <td>3</td>
      <td>0,26</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>520655900</td>
      <td>11</td>
      <td>50130</td>
      <td>Безсмертний Роман Петрович</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>2</td>
      <td>0,17</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>520655900</td>
      <td>11</td>
      <td>50130</td>
      <td>Богомолець Ольга Вадимівна</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>2</td>
      <td>0,17</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>520655900</td>
      <td>11</td>
      <td>50130</td>
      <td>Богословська Інна Германівна</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>520655900</td>
      <td>11</td>
      <td>50130</td>
      <td>Бойко Юрій Анатолійович</td>
      <td>Самовисування</td>
      <td>Опозиційний блок</td>
      <td>32</td>
      <td>2,85</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1169566</th>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>900125</td>
      <td>Тарута Сергій Олексійович</td>
      <td>Основа</td>
      <td>Основа</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169567</th>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>900125</td>
      <td>Тимошенко Юлія Володимирівна</td>
      <td>Батьківщина</td>
      <td>Батьківщина</td>
      <td>10</td>
      <td>4,31</td>
    </tr>
    <tr>
      <th>1169568</th>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>900125</td>
      <td>Тимошенко Юрій Володимирович</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169569</th>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>900125</td>
      <td>Шевченко Ігор Анатолійович</td>
      <td>Самовисування</td>
      <td>Безпартійний</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169570</th>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>9000000124</td>
      <td>226</td>
      <td>900125</td>
      <td>Шевченко Олександр Леонідович</td>
      <td>УКРОП</td>
      <td>УКРОП</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>1169571 rows × 11 columns</p>
</div>



Let's watch how many votes were for each party


```python
results_df[['vote_count', 'party']].groupby('party').sum()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>vote_count</th>
    </tr>
    <tr>
      <th>party</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Батьківщина</th>
      <td>2532452</td>
    </tr>
    <tr>
      <th>Воля</th>
      <td>19542</td>
    </tr>
    <tr>
      <th>Відродження</th>
      <td>22564</td>
    </tr>
    <tr>
      <th>Громадянська позиція</th>
      <td>1306450</td>
    </tr>
    <tr>
      <th>Народний Рух</th>
      <td>9243</td>
    </tr>
    <tr>
      <th>Опозиційний блок – партія миру та розвитку</th>
      <td>784274</td>
    </tr>
    <tr>
      <th>Основа</th>
      <td>18918</td>
    </tr>
    <tr>
      <th>Партія "5.10"</th>
      <td>32872</td>
    </tr>
    <tr>
      <th>Патріот</th>
      <td>5587</td>
    </tr>
    <tr>
      <th>Радикальна партія Ляшка</th>
      <td>1036003</td>
    </tr>
    <tr>
      <th>Розумна сила</th>
      <td>5331</td>
    </tr>
    <tr>
      <th>Рух Наливайченка</th>
      <td>43239</td>
    </tr>
    <tr>
      <th>Самовисування</th>
      <td>6680340</td>
    </tr>
    <tr>
      <th>Свобода</th>
      <td>307244</td>
    </tr>
    <tr>
      <th>Слуга народу</th>
      <td>5714034</td>
    </tr>
    <tr>
      <th>Соц.партія Мороза</th>
      <td>13139</td>
    </tr>
    <tr>
      <th>Соціал-демократична партія</th>
      <td>14532</td>
    </tr>
    <tr>
      <th>Соціалістична партія</th>
      <td>5869</td>
    </tr>
    <tr>
      <th>Стабільність</th>
      <td>8453</td>
    </tr>
    <tr>
      <th>УКРОП</th>
      <td>109078</td>
    </tr>
  </tbody>
</table>
</div>



Let's watch num of votes per each candidate


```python
# groupping results per candidate
votes_per_candidate = results_df[['vote_count', 'candidate']].groupby('candidate').sum().reset_index()
# sum_votes is sum of all votes in elections
sum_votes = protokols_df['votes_candidates'].sum()
# view the votes per candidate
votes_per_candidate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>vote_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>32872</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Безсмертний Роман Петрович</td>
      <td>27182</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Богомолець Ольга Вадимівна</td>
      <td>33966</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Богословська Інна Германівна</td>
      <td>18482</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Бойко Юрій Анатолійович</td>
      <td>2206216</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Бондар Віктор Васильович</td>
      <td>22564</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Ващенко Олександр Михайлович</td>
      <td>5503</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Вілкул Олександр Юрійович</td>
      <td>784274</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Габер Микола Олександрович</td>
      <td>5433</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>1306450</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Данилюк Олександр Володимирович</td>
      <td>4648</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Дерев’янко Юрій Богданович</td>
      <td>19542</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Журавльов Василь Миколайович</td>
      <td>8453</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>5714034</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Каплін Сергій Миколайович</td>
      <td>14532</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Кармазін Юрій Анатолійович</td>
      <td>15965</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Кива Ілля Володимирович</td>
      <td>5869</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Корнацький Аркадій Олексійович</td>
      <td>4494</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Кошулинський Руслан Володимирович</td>
      <td>307244</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Кривенко Віктор Миколайович</td>
      <td>9243</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Купрій Віталій Миколайович</td>
      <td>4508</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Литвиненко Юлія Леонідівна</td>
      <td>20014</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Ляшко Олег Валерійович</td>
      <td>1036003</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Мороз Олександр Олександрович</td>
      <td>13139</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Наливайченко Валентин Олександрович</td>
      <td>43239</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Насіров Роман Михайлович</td>
      <td>2579</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Новак Андрій Яремович</td>
      <td>5587</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Носенко Сергій Михайлович</td>
      <td>3114</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Петров Володимир Володимирович</td>
      <td>15587</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Порошенко Петро Олексійович</td>
      <td>3014609</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Ригованов Руслан Олександрович</td>
      <td>5230</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Скоцик Віталій Євстафійович</td>
      <td>15118</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Смешко Ігор Петрович</td>
      <td>1141332</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Соловйов Олександр Миколайович</td>
      <td>5331</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Тарута Сергій Олексійович</td>
      <td>18918</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Тимошенко Юлія Володимирівна</td>
      <td>2532452</td>
    </tr>
    <tr>
      <th>36</th>
      <td>Тимошенко Юрій Володимирович</td>
      <td>117693</td>
    </tr>
    <tr>
      <th>37</th>
      <td>Шевченко Ігор Анатолійович</td>
      <td>18667</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>109078</td>
    </tr>
  </tbody>
</table>
</div>



Make a sample with candidates can cross the border of 5% of votes


```python
# creating dataframe for finding the percent of votes per every candidate
candidate_percent = pd.DataFrame()
candidate_percent['candidate'] = votes_per_candidate['candidate']
candidate_percent['candidate_percent'] = votes_per_candidate['vote_count'] / sum_votes * 100

# filtering only candidates with more than 5% of votes
concurence_candidates = candidate_percent[candidate_percent['candidate_percent'] > 5]['candidate'].to_list()
# concurence_candidates is a list of candidates with > 5% of elections
concurence_candidates
```




    ['Бойко Юрій Анатолійович',
     'Гриценко Анатолій Степанович',
     'Зеленський Володимир Олександрович',
     'Ляшко Олег Валерійович',
     'Порошенко Петро Олексійович',
     'Смешко Ігор Петрович',
     'Тимошенко Юлія Володимирівна']




```python
results_df[['vote_count']].sum()
```




    vote_count    18669164
    dtype: int64




```python
protokols_df['votes_candidates'].sum()
```




    18669164



Let's watch the distribution of votes per region and see the difference between protokols and results file 


```python
results_df[['region', 'vote_count']].groupby('region').sum()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>vote_count</th>
    </tr>
    <tr>
      <th>region</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Івано-Франківська область</th>
      <td>642930</td>
    </tr>
    <tr>
      <th>Волинська область</th>
      <td>514692</td>
    </tr>
    <tr>
      <th>Вінницька область</th>
      <td>790432</td>
    </tr>
    <tr>
      <th>Дніпропетровська область</th>
      <td>1628887</td>
    </tr>
    <tr>
      <th>Донецька область</th>
      <td>836485</td>
    </tr>
    <tr>
      <th>Житомирська область</th>
      <td>611361</td>
    </tr>
    <tr>
      <th>За межами України</th>
      <td>54694</td>
    </tr>
    <tr>
      <th>Закарпатська область</th>
      <td>433665</td>
    </tr>
    <tr>
      <th>Запорізька область</th>
      <td>862465</td>
    </tr>
    <tr>
      <th>Київська область</th>
      <td>972235</td>
    </tr>
    <tr>
      <th>Кіровоградська область</th>
      <td>448559</td>
    </tr>
    <tr>
      <th>Луганська область</th>
      <td>299059</td>
    </tr>
    <tr>
      <th>Львівська область</th>
      <td>1311065</td>
    </tr>
    <tr>
      <th>Миколаївська область</th>
      <td>519612</td>
    </tr>
    <tr>
      <th>Одеська область</th>
      <td>1012005</td>
    </tr>
    <tr>
      <th>Полтавська область</th>
      <td>727923</td>
    </tr>
    <tr>
      <th>Рівненська область</th>
      <td>545369</td>
    </tr>
    <tr>
      <th>Сумська область</th>
      <td>551258</td>
    </tr>
    <tr>
      <th>Тернопільська область</th>
      <td>530560</td>
    </tr>
    <tr>
      <th>Харківська область</th>
      <td>1310201</td>
    </tr>
    <tr>
      <th>Херсонська область</th>
      <td>463864</td>
    </tr>
    <tr>
      <th>Хмельницька область</th>
      <td>642542</td>
    </tr>
    <tr>
      <th>Черкаська область</th>
      <td>608296</td>
    </tr>
    <tr>
      <th>Чернівецька область</th>
      <td>379545</td>
    </tr>
    <tr>
      <th>Чернігівська область</th>
      <td>524507</td>
    </tr>
    <tr>
      <th>м. Київ</th>
      <td>1446953</td>
    </tr>
  </tbody>
</table>
</div>




```python
protokols_df[['region', 'votes_candidates']].groupby('region').sum()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>votes_candidates</th>
    </tr>
    <tr>
      <th>region</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Івано-Франківська область</th>
      <td>642930</td>
    </tr>
    <tr>
      <th>Волинська область</th>
      <td>514692</td>
    </tr>
    <tr>
      <th>Вінницька область</th>
      <td>790432</td>
    </tr>
    <tr>
      <th>Дніпропетровська область</th>
      <td>1628887</td>
    </tr>
    <tr>
      <th>Донецька область</th>
      <td>836485</td>
    </tr>
    <tr>
      <th>Житомирська область</th>
      <td>611361</td>
    </tr>
    <tr>
      <th>За межами України</th>
      <td>54694</td>
    </tr>
    <tr>
      <th>Закарпатська область</th>
      <td>433665</td>
    </tr>
    <tr>
      <th>Запорізька область</th>
      <td>862465</td>
    </tr>
    <tr>
      <th>Київська область</th>
      <td>972235</td>
    </tr>
    <tr>
      <th>Кіровоградська область</th>
      <td>448559</td>
    </tr>
    <tr>
      <th>Луганська область</th>
      <td>299059</td>
    </tr>
    <tr>
      <th>Львівська область</th>
      <td>1311065</td>
    </tr>
    <tr>
      <th>Миколаївська область</th>
      <td>519612</td>
    </tr>
    <tr>
      <th>Одеська область</th>
      <td>1012005</td>
    </tr>
    <tr>
      <th>Полтавська область</th>
      <td>727923</td>
    </tr>
    <tr>
      <th>Рівненська область</th>
      <td>545369</td>
    </tr>
    <tr>
      <th>Сумська область</th>
      <td>551258</td>
    </tr>
    <tr>
      <th>Тернопільська область</th>
      <td>530560</td>
    </tr>
    <tr>
      <th>Харківська область</th>
      <td>1310201</td>
    </tr>
    <tr>
      <th>Херсонська область</th>
      <td>463864</td>
    </tr>
    <tr>
      <th>Хмельницька область</th>
      <td>642542</td>
    </tr>
    <tr>
      <th>Черкаська область</th>
      <td>608296</td>
    </tr>
    <tr>
      <th>Чернівецька область</th>
      <td>379545</td>
    </tr>
    <tr>
      <th>Чернігівська область</th>
      <td>524507</td>
    </tr>
    <tr>
      <th>м. Київ</th>
      <td>1446953</td>
    </tr>
  </tbody>
</table>
</div>



There are no difference

#### Distribution of score votes in precints


```python
# function which print simple histogram 
def plot_plt_histogram(set_x, bins, grid=False, hight=70, weight=100, fontsize=30,
                       need_xlim=False, xlim=1000, xmin=0,
                       need_ylim=False, ylim=1000, ymin=0,
                       need_tick=False, tick_x=100, tick_y=100,
                       hist_name='Histogram'):
    # plotting the histogram
    fig = plt.figure(figsize=(weight, hight))
    ax = fig.add_subplot(111)
    ax.hist(set_x, bins=bins)
    if need_xlim == True:
        plt.xlim(xmin, xlim)
    if need_ylim == True:
        plt.ylim(ymin, ylim)
    plt.title(hist_name, fontsize=fontsize)
    plt.grid(grid)
                # adding the ticks
    if need_tick == True:
        ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_x))
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(tick_x / 2))
        ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_y))
        ax.yaxis.set_minor_locator(ticker.MultipleLocator(tick_y / 2))
        ax.minorticks_on()
        ax.grid(which='minor',
                    color = 'gray',
                    linestyle = ':')
        plt.tick_params(axis='x', labelsize=fontsize)
        plt.tick_params(axis='y', labelsize=fontsize)
    plt.show()
    

    
# printing the histogram    
plot_plt_histogram(protokols_df['votes_candidates'], bins=protokols_df['votes_candidates'].shape[0]//5,
                   grid=True, hight=20, weight=50, need_tick=True, tick_x=100, tick_y=10, 
                   hist_name='Distributionthe number of votes in election',
                   need_xlim=True, xlim=2000)

# information about distribution the data
hist = protokols_df['votes_candidates'].groupby(protokols_df['votes_candidates']).count()
hist = pd.DataFrame(hist).rename(columns={'votes_candidates' : 'count'}).reset_index()
# testing that distribution is normal
stats.probplot(protokols_df['votes_candidates'], dist='norm', plot=plt)
plt.show()
# print information about distribution the data 
print(hist)
print('median: ', protokols_df['votes_candidates'].median())
```


    
![png](output_26_0.png)
    



    
![png](output_26_1.png)
    


          votes_candidates  count
    0                    1      1
    1                    2      1
    2                    4      6
    3                    5      3
    4                    6      8
    ...                ...    ...
    1772              2056      1
    1773              2081      1
    1774              2150      1
    1775              3712      1
    1776              4129      1
    
    [1777 rows x 2 columns]
    median:  467.0
    


```python
# printing the histogram    
plot_plt_histogram(protokols_df['voted_total_percent'], bins=90,
                   grid=True, hight=20, weight=40, fontsize=30,
                   need_ylim=True, ylim=2000, need_tick=True, tick_x=10, tick_y=200,
                   need_xlim=True, xlim=101,
                   hist_name='Distribution of turnout per percint')

# information about distribution the data
hist = protokols_df['voted_total_percent'].groupby(protokols_df['voted_total_percent']).count()
hist = pd.DataFrame(hist).rename(columns={'voted_total_percent' : 'count'}).reset_index()
# testing that distribution is normal
stats.probplot(protokols_df['voted_total_percent'], dist='norm', plot=plt)
plt.show()
# print information about distribution the data 
print(hist)
print('median: ', protokols_df['voted_total_percent'].median())
```


    
![png](output_27_0.png)
    



    
![png](output_27_1.png)
    


          voted_total_percent  count
    0                    1.50      1
    1                    1.67      1
    2                    2.12      1
    3                    2.13      1
    4                    2.48      1
    ...                   ...    ...
    4576                99.81      1
    4577                99.82      1
    4578                99.83      1
    4579                99.84      2
    4580               100.00    332
    
    [4581 rows x 2 columns]
    median:  65.23
    

## The distribution of votes per turnout in precints. Rounded to 1% step.


```python
# function which print the simple plot
def print_plot(x, y, need_z=False, z=0, 
              grid=True, hight=5, weight=8, 
              need_legend=False, legend_y='', legend_z='', legend_fontsize=20, 
              plot_name='', color='C1',
              need_xlim=False, xlim=0, xmin=0, need_ylim=False, ylim=0, ymin=0,
              need_label = False, ylabel='', xlabel='',
              need_tick=False, tick_x=5, tick_y=100):
    # print the plot
    fig = plt.figure(figsize=(weight, hight))
    ax = fig.add_subplot(111)
    ax.plot(x, y, color)
    if need_z == True:
        ax.plot(z)
    ax.grid(grid, which='major')
    ax.set_title(plot_name, fontsize=legend_fontsize)
    if need_tick == True:
        ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_x))
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(tick_x / 2))
        ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_y))
        ax.yaxis.set_minor_locator(ticker.MultipleLocator(tick_y / 2))
        ax.minorticks_on()
        ax.grid(which='minor',
                    color = 'gray',
                    linestyle = ':')
    if need_label == True:
        plt.xlabel(xlabel, fontsize=legend_fontsize)
        plt.ylabel(ylabel, fontsize=legend_fontsize)
    if need_legend == True:
        ax.legend((legend_y, legend_z), frameon=True, fontsize=legend_fontsize)
    if need_xlim == True:
        plt.xlim(xmin, xlim)
    if need_ylim == True:
        plt.ylim(ymin, ylim)
    plt.show()

    
```


```python
# preprocessing data in protokols
protokols_df['voted_total_percent_rounded'] = protokols_df['voted_total_percent'].round(0).copy()
voted_total_percent = protokols_df[['voted_total', 'voted_total_percent_rounded']].groupby(
                                                                                    'voted_total_percent_rounded').sum()
voted_total_percent = pd.DataFrame(voted_total_percent).reset_index()

# printing the distribution of number of voted_total and voted_total_percent
print_plot(voted_total_percent['voted_total_percent_rounded'], voted_total_percent['voted_total'], 
           plot_name='Votes per turnout  Score', hight=10, weight=25, grid=True, color='C0', 
           need_legend=True, legend_y='votes in milions', legend_fontsize=20,
           need_label = True, ylabel='votes', xlabel='turnout',
           need_xlim=True, xlim=100, xmin=0, need_ylim=True, ylim=1300000, ymin=0,
           need_tick=True, tick_x=5, tick_y=100000)
voted_total_percent
```


    
![png](output_30_0.png)
    





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>voted_total_percent_rounded</th>
      <th>voted_total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.0</td>
      <td>1973</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3.0</td>
      <td>794</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4.0</td>
      <td>175</td>
    </tr>
    <tr>
      <th>3</th>
      <td>6.0</td>
      <td>870</td>
    </tr>
    <tr>
      <th>4</th>
      <td>7.0</td>
      <td>4510</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>93</th>
      <td>96.0</td>
      <td>11209</td>
    </tr>
    <tr>
      <th>94</th>
      <td>97.0</td>
      <td>10126</td>
    </tr>
    <tr>
      <th>95</th>
      <td>98.0</td>
      <td>12200</td>
    </tr>
    <tr>
      <th>96</th>
      <td>99.0</td>
      <td>15985</td>
    </tr>
    <tr>
      <th>97</th>
      <td>100.0</td>
      <td>48748</td>
    </tr>
  </tbody>
</table>
<p>98 rows × 2 columns</p>
</div>




```python
# testing that distribution is normal
stats.probplot(protokols_df['voted_total_percent_rounded'], dist='norm', plot=plt)
plt.show()
```


    
![png](output_31_0.png)
    



```python
# printing the distribution of vote_count per every candidate in each precint
results_df[['precinct_no', 'candidate', 'vote_count']]

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>precinct_no</th>
      <th>candidate</th>
      <th>vote_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>50130</td>
      <td>Балашов Геннадій Вікторович</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1</th>
      <td>50130</td>
      <td>Безсмертний Роман Петрович</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>50130</td>
      <td>Богомолець Ольга Вадимівна</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>50130</td>
      <td>Богословська Інна Германівна</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>50130</td>
      <td>Бойко Юрій Анатолійович</td>
      <td>32</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1169566</th>
      <td>900125</td>
      <td>Тарута Сергій Олексійович</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169567</th>
      <td>900125</td>
      <td>Тимошенко Юлія Володимирівна</td>
      <td>10</td>
    </tr>
    <tr>
      <th>1169568</th>
      <td>900125</td>
      <td>Тимошенко Юрій Володимирович</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169569</th>
      <td>900125</td>
      <td>Шевченко Ігор Анатолійович</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1169570</th>
      <td>900125</td>
      <td>Шевченко Олександр Леонідович</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>1169571 rows × 3 columns</p>
</div>




```python
# grouping results by candidate and precint
results_total = results_df[['district_no', 
                            'precinct_no', 
                            'candidate', 
                            'vote_count']].groupby(['candidate',
                                                    'district_no', 
                                                    'precinct_no']).sum().reset_index()

# let's watch the result for Zelensky in 12's district
results_total[(results_total['candidate'] == 'Зеленський Володимир Олександрович') & (results_total['district_no'] == 12)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>389971</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>1</td>
      <td>239</td>
    </tr>
    <tr>
      <th>389972</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>50125</td>
      <td>94</td>
    </tr>
    <tr>
      <th>389973</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>50126</td>
      <td>281</td>
    </tr>
    <tr>
      <th>389974</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>50127</td>
      <td>176</td>
    </tr>
    <tr>
      <th>389975</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>50128</td>
      <td>153</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>390082</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>51588</td>
      <td>13</td>
    </tr>
    <tr>
      <th>390083</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>51589</td>
      <td>107</td>
    </tr>
    <tr>
      <th>390084</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>51590</td>
      <td>100</td>
    </tr>
    <tr>
      <th>390085</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>51670</td>
      <td>343</td>
    </tr>
    <tr>
      <th>390086</th>
      <td>Зеленський Володимир Олександрович</td>
      <td>12</td>
      <td>51674</td>
      <td>347</td>
    </tr>
  </tbody>
</table>
<p>116 rows × 4 columns</p>
</div>




```python
results_total_joined = results_total.join(protokols_df[['region', 'rayon', 'community',
                                                 'district_no', 
                                                 'precinct_no',
                                                 'votes_candidates',
                                                 'voted_total_percent_rounded']].set_index(['district_no','precinct_no']), 
                                   on=['district_no', 'precinct_no'], how='right')

results_total_joined
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>votes_candidates</th>
      <th>voted_total_percent_rounded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>11</td>
      <td>50130</td>
      <td>3</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>29989</th>
      <td>Безсмертний Роман Петрович</td>
      <td>11</td>
      <td>50130</td>
      <td>2</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>59978</th>
      <td>Богомолець Ольга Вадимівна</td>
      <td>11</td>
      <td>50130</td>
      <td>2</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>89967</th>
      <td>Богословська Інна Германівна</td>
      <td>11</td>
      <td>50130</td>
      <td>0</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>119956</th>
      <td>Бойко Юрій Анатолійович</td>
      <td>11</td>
      <td>50130</td>
      <td>32</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1049614</th>
      <td>Тарута Сергій Олексійович</td>
      <td>226</td>
      <td>900125</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>1079603</th>
      <td>Тимошенко Юлія Володимирівна</td>
      <td>226</td>
      <td>900125</td>
      <td>10</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>1109592</th>
      <td>Тимошенко Юрій Володимирович</td>
      <td>226</td>
      <td>900125</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>1139581</th>
      <td>Шевченко Ігор Анатолійович</td>
      <td>226</td>
      <td>900125</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>1169570</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>226</td>
      <td>900125</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.0</td>
    </tr>
  </tbody>
</table>
<p>1169571 rows × 9 columns</p>
</div>




```python
results_total = results_total_joined.groupby(['candidate', 'voted_total_percent_rounded']).sum().reset_index()
results_total
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>voted_total_percent_rounded</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>votes_candidates</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>2.0</td>
      <td>964</td>
      <td>3740649</td>
      <td>9</td>
      <td>1960</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>3.0</td>
      <td>678</td>
      <td>2700109</td>
      <td>5</td>
      <td>786</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>4.0</td>
      <td>226</td>
      <td>900099</td>
      <td>0</td>
      <td>174</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>6.0</td>
      <td>524</td>
      <td>2010605</td>
      <td>7</td>
      <td>861</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>7.0</td>
      <td>1130</td>
      <td>4500255</td>
      <td>20</td>
      <td>4483</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3817</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>96.0</td>
      <td>9376</td>
      <td>31699644</td>
      <td>45</td>
      <td>10852</td>
    </tr>
    <tr>
      <th>3818</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>97.0</td>
      <td>6701</td>
      <td>22773657</td>
      <td>71</td>
      <td>9773</td>
    </tr>
    <tr>
      <th>3819</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>98.0</td>
      <td>6938</td>
      <td>23116403</td>
      <td>45</td>
      <td>11757</td>
    </tr>
    <tr>
      <th>3820</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>99.0</td>
      <td>5746</td>
      <td>16231457</td>
      <td>67</td>
      <td>15241</td>
    </tr>
    <tr>
      <th>3821</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>100.0</td>
      <td>39676</td>
      <td>118975785</td>
      <td>203</td>
      <td>46636</td>
    </tr>
  </tbody>
</table>
<p>3822 rows × 6 columns</p>
</div>




```python
protokols_df[['voted_total_percent_rounded', 'voted_total',
                'precinct_no', 'district_no']][(protokols_df['district_no'] == 12)  & (protokols_df['precinct_no'] == 1)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>voted_total_percent_rounded</th>
      <th>voted_total</th>
      <th>precinct_no</th>
      <th>district_no</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>114</th>
      <td>99.0</td>
      <td>706</td>
      <td>1</td>
      <td>12</td>
    </tr>
  </tbody>
</table>
</div>




```python
# select the first candidate for creating the first plot
first_candidate = concurence_candidates[0]
x = results_total.reset_index()['voted_total_percent_rounded'][results_total['candidate'] == first_candidate]
y = results_total['vote_count'][results_total['candidate'] == first_candidate]
y

```




    392     281
    393     169
    394      11
    395      46
    396     257
           ... 
    485    1335
    486    1237
    487    1023
    488    1219
    489    3235
    Name: vote_count, Length: 98, dtype: int64




```python
# function for printing the any nums of plots in one figure with common x-axis
def print_multiply_plot(dataset, x_column='', y_column='', target_column='', target_list=[], mult_type='in_one',
              grid=True, hight=5, weight=8, 
              need_legend=False, legend_fontsize=20, 
              plot_name='scatter', color='C1',
              need_xlim=False, xlim=0, xmin=0, need_ylim=False, ylim=0, ymin=0,
              need_label = False, ylabel='', xlabel='', need_print = 'N',
              need_tick=False, tick_x=5, tick_y=100):
    # mult_type = ['in_one', 'in_differ']
    
    # x cannot be changed
    # sampling the x
    x = dataset[x_column][dataset[target_column] == target_list[0]]
    
    if mult_type == 'in_one':
        fig = plt.figure(figsize=(weight, hight))
        ax = fig.add_subplot(111)
        # tittle
        ax.set_title(plot_name, fontsize=legend_fontsize)

        # labels for every axis
        plt.xlabel(xlabel, fontsize=legend_fontsize)
        plt.ylabel(ylabel, fontsize=legend_fontsize)

        # grid 
        ax.grid(True, which='major')

        # adding the tickers
        ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_x))
        ax.xaxis.set_minor_locator(ticker.MultipleLocator(tick_x / 2))
        ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_y))
        ax.yaxis.set_minor_locator(ticker.MultipleLocator(tick_x / 2))
        ax.minorticks_on()
        ax.grid(which='minor',color = 'gray', linestyle = ':')

        plt.xlim(xmin, xlim)
        plt.ylim(ymin, ylim)

        # adding others plots
        for element in target_list:   
            y = dataset[y_column][dataset[target_column] == element]
            ax.plot(x, y)
            
        # legend
        if need_legend == True:
            ax.legend(target_list, frameon=True, fontsize=legend_fontsize, markerscale=5.0)
        plt.savefig(plot_name+'.jpg')
        # printing if need
        if need_print == 'Y':
            plt.show() 
        
    if mult_type == 'in_differ':
        for element in target_list:
            fig = plt.figure(figsize=(weight, hight))
            ax = fig.add_subplot(111)
            # tittle
            ax.set_title(plot_name, fontsize=font_size)

            # labels for every axis
            plt.xlabel(xlabel, fontsize=font_size)
            plt.ylabel(ylabel, fontsize=font_size)

            # grid 
            ax.grid(True, which='major')

            # adding the tickers
            ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_x))
            ax.xaxis.set_minor_locator(ticker.MultipleLocator(tick_x / 2))
            ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_y))
            ax.yaxis.set_minor_locator(ticker.MultipleLocator(tick_y / 2))
            ax.minorticks_on()
            ax.grid(which='minor',color = 'gray', linestyle = ':')

            plt.xlim(xmin, xlim)
            plt.ylim(ymin, ylim)            
            
            y = dataset[y_column][dataset[target_column] == element]
            element_color = 'C' + str(target_list.index(element))
            
            ax.plot(x, y, color=element_color)
            
            # legend
            if need_legend == True:
                ax.legend(target_list, frameon=True, fontsize=legend_fontsize, markerscale=5.0)
            plt.savefig(plot_name+element+'.jpg')
            # printing if need 
            if need_print == 'Y':
                plt.show()  
```


```python
# variables for plotting
weight, hight = 10 , 10
font_size = 10
xlabel = 'turnout in %'
ylabel = 'votes'
tick_x = 10
tick_y = 50000
plot_name = 'Votes per turnout for each candidate'
xmin, xlim = 0, 100
ymin, ylim = 0, 410000
dataset = results_total
x_column = 'voted_total_percent_rounded'
y_column = 'vote_count'
target_column = 'candidate'
target_list = concurence_candidates

print_multiply_plot(dataset, x_column=x_column, y_column=y_column, 
              target_column=target_column, target_list=target_list, mult_type='in_one',
              grid=True, hight=hight, weight=weight, 
              need_legend=True, legend_fontsize=font_size, 
              plot_name=plot_name,
              need_xlim=True, xlim=100, xmin=0, need_ylim=True, ylim=410000, ymin=0,
              need_label = True, ylabel=ylabel, xlabel=xlabel,
              need_tick=True, tick_x=tick_x, tick_y=tick_y)
```


    
![png](output_39_0.png)
    



```python
# grouping the results by candidate, district and precint for getting sum of votes 
results_total = results_df[['district_no', 
                            'precinct_no', 
                            'candidate', 
                            'vote_count',
                           ]].groupby(['candidate',
                                        'district_no', 
                                        'precinct_no']).sum().reset_index()
# merging the protokols for getting info about precints and all votes per precints
results_total = results_total.join(protokols_df[['region', 'rayon', 'community',
                                                 'district_no', 
                                                 'precinct_no',
                                                 'votes_candidates',
                                                 'voted_total_percent']].set_index(['district_no','precinct_no']), 
                                   on=['district_no', 'precinct_no'], how='left')
# finding the percents of votes in precint per all votes in precint
results_total['candidate_percent_per_precint'] = results_total['vote_count'] / results_total['votes_candidates'] * 100
results_total
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>votes_candidates</th>
      <th>voted_total_percent</th>
      <th>candidate_percent_per_precint</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>11</td>
      <td>50130</td>
      <td>3</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.48</td>
      <td>0.272480</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>11</td>
      <td>50131</td>
      <td>1</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1341</td>
      <td>64.39</td>
      <td>0.074571</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>11</td>
      <td>50132</td>
      <td>1</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>822</td>
      <td>65.60</td>
      <td>0.121655</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>11</td>
      <td>50133</td>
      <td>2</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1583</td>
      <td>65.48</td>
      <td>0.126342</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Балашов Геннадій Вікторович</td>
      <td>11</td>
      <td>50134</td>
      <td>1</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>140</td>
      <td>62.22</td>
      <td>0.714286</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1169566</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>226</td>
      <td>900121</td>
      <td>1</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>540</td>
      <td>13.02</td>
      <td>0.185185</td>
    </tr>
    <tr>
      <th>1169567</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>226</td>
      <td>900122</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1434</td>
      <td>6.79</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1169568</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>226</td>
      <td>900123</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59</td>
      <td>64.83</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1169569</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>226</td>
      <td>900124</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>122</td>
      <td>77.21</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>1169570</th>
      <td>Шевченко Олександр Леонідович</td>
      <td>226</td>
      <td>900125</td>
      <td>0</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.27</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
<p>1169571 rows × 10 columns</p>
</div>




```python
# function which print the multiply identical plots with common x=axis
def print_multiply_scatter(dataset, x_column='', y_column='', target_column='', target_list=[], mult_type='in_one',
              grid=True, hight=5, weight=8, 
              need_legend=False, legend_fontsize=20, 
              plot_name='scatter', color='C1',
              need_xlim=False, xlim=0, xmin=0, need_ylim=False, ylim=0, ymin=0,
              need_label = False, ylabel='', xlabel='', need_print='N',
              need_tick=False, tick_x=5, tick_y=100):
    # mult_type = ['in_one', 'in_differ']
    
    # x cannot be changed
    # sampling the x
    x = dataset[x_column][dataset[target_column] == target_list[0]]
    
    # checking mult_type
    if mult_type == 'in_one':
            # print the plot
        fig = plt.figure(figsize=(weight, hight), dpi=100, frameon=False)
        ax = fig.add_subplot(111)
            # adding the grid
        ax.grid(grid, which='major')
        ax.set_title(plot_name, fontsize=legend_fontsize)
    
        # adding the title
        if need_tick == True:
            ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_x))
            ax.xaxis.set_minor_locator(ticker.MultipleLocator(tick_x / 2))
            ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_y))
            ax.yaxis.set_minor_locator(ticker.MultipleLocator(tick_y / 2))
            ax.minorticks_on()
            ax.grid(which='minor',
                    color = 'gray',
                    linestyle = ':')
            plt.tick_params(axis='x', labelsize=legend_fontsize)
            plt.tick_params(axis='y', labelsize=legend_fontsize)
        if need_label == True:
            plt.xlabel(xlabel, fontsize=legend_fontsize)
            plt.ylabel(ylabel, fontsize=legend_fontsize)
        if need_xlim == True:
            plt.xlim(xmin, xlim)
        if need_ylim == True:
            plt.ylim(ymin, ylim)
            # cycle for getting the plot from sample of y

        # cycle for getting the plot from sample of y
    for element in target_list:
        if mult_type == 'in_differ':
            fig = plt.figure(figsize=(weight, hight), dpi=100, frameon=False)
            ax = fig.add_subplot(111)
    
            # adding the grid
            ax.grid(grid, which='major')
            ax.set_title(plot_name, fontsize=legend_fontsize)
    
            # adding the ticks
            if need_tick == True:
                ax.xaxis.set_major_locator(ticker.MultipleLocator(tick_x))
                ax.xaxis.set_minor_locator(ticker.MultipleLocator(tick_x / 2))
                ax.yaxis.set_major_locator(ticker.MultipleLocator(tick_y))
                ax.yaxis.set_minor_locator(ticker.MultipleLocator(tick_y / 2))
                ax.minorticks_on()
                ax.grid(which='minor',
                    color = 'gray',
                    linestyle = ':')
                plt.tick_params(axis='x', labelsize=legend_fontsize)
                plt.tick_params(axis='y', labelsize=legend_fontsize)
            # adding the label 
            if need_label == True:
                plt.xlabel(xlabel, fontsize=legend_fontsize)
                plt.ylabel(ylabel, fontsize=legend_fontsize)
            if need_xlim == True:
                plt.xlim(xmin, xlim)
            if need_ylim == True:
                plt.ylim(ymin, ylim)  
            
            y = dataset[y_column][dataset[target_column] == element]
            
            element_color = 'C' + str(target_list.index(element))
            ax.scatter(x, y, c=element_color, s=0.7)
            if need_legend == True:
                ax.legend([element], frameon=True, fontsize=legend_fontsize, markerscale=legend_fontsize//2)
            plt.savefig(plot_name+str(element)+'.jpg')
            if need_print == 'Y':
                plt.show()
        else:
            y = dataset[y_column][dataset[target_column] == element]
            ax.scatter(x, y, s=0.7)
                       
    if mult_type == 'in_one':
        if need_legend == True:
            ax.legend(target_list, frameon=True, fontsize=legend_fontsize, markerscale=legend_fontsize//2) 
        plt.savefig(plot_name+'.jpg')
        if need_print == 'Y':
            plt.show()   
```


```python
# prnting the percent's distribution for every candidate in one plot
print_multiply_scatter(results_total, x_column='voted_total_percent', y_column='candidate_percent_per_precint', 
              target_column='candidate', target_list=concurence_candidates, mult_type='in_one',
              grid=True, hight=10, weight=10, 
              need_legend=True, legend_fontsize=10,
              plot_name='Percent of votes in precint per turnout',
              need_xlim=True, xlim=101, xmin=0, need_ylim=True, ylim=101, ymin=0,
              need_label=True, ylabel='percent of votes in percint', xlabel='turnout in %', need_print='Y',
              need_tick=True, tick_x=5, tick_y=5)        

```

    <ipython-input-31-f606a0e6f12b>:92: UserWarning: Creating legend with loc="best" can be slow with large amounts of data.
      plt.savefig(plot_name+'.jpg')
    d:\pyth3_8_5\lib\site-packages\IPython\core\pylabtools.py:132: UserWarning: Creating legend with loc="best" can be slow with large amounts of data.
      fig.canvas.print_figure(bytes_io, **kw)
    


    
![png](output_42_1.png)
    



```python
print_multiply_scatter(results_total, x_column='voted_total_percent', y_column='candidate_percent_per_precint', 
              target_column='candidate', target_list=concurence_candidates, mult_type='in_differ',
              grid=True, hight=10, weight=10, 
              need_legend=True, legend_fontsize=11,
              plot_name='elections',
              need_xlim=True, xlim=101, xmin=0, need_ylim=True, ylim=101, ymin=0,
              need_label=True, ylabel='percent of votes in percint', xlabel='turnout in %',
              need_tick=True, tick_x=5, tick_y=5) 
```


    
![png](output_43_0.png)
    



    
![png](output_43_1.png)
    



    
![png](output_43_2.png)
    



    
![png](output_43_3.png)
    



    
![png](output_43_4.png)
    



    
![png](output_43_5.png)
    



    
![png](output_43_6.png)
    


#### For every region


```python
# common variables
xmin, xlim = 0, 100
 # ticks
tick_x = 5

target_column = 'candidate'
target_list = concurence_candidates
region_list = list(results_total_joined[results_total_joined['region'] != 'За межами України']['region'].unique())

# variables for plot
weight_plot, hight_plot = 10 , 10
font_size_plot = 10
tick_y_plot = 5000

xlabel_plot = 'turnout in %'
ylabel_plot = 'votes'
x_column_plot = 'voted_total_percent_rounded'
y_column_plot = 'vote_count'

# variables for scatter
weight_scatter, hight_scatter = 8 , 8
font_size_scatter = 8
tick_y_scatter = 5

xlabel_scatter = 'turnout in %'
ylabel_scatter = '% of precint for candidate'
x_column_scatter = 'voted_total_percent'
y_column_scatter = 'candidate_percent_per_precint'


# loop for printing the plot and scatter for each region
for region in region_list:
    # making region's sample
    dataset_plot = results_total_joined[results_total_joined['region'] == region]
    # grouping per candidate
    dataset_plot = dataset_plot.groupby(['candidate', 'voted_total_percent_rounded']).sum().reset_index()
    
    dataset_scatter = results_total[results_total['region'] == region]
    
    # additional values for printing the plots
    # border for every plot
    ymin, ylim = 0, dataset_plot[y_column].max()+0.2 * dataset_plot[y_column].max()
    
    # plot name
    plot_name_plot = 'Votes per turnout for each candidate' +' in '+'#'+ region+'# plot'
    plot_name_scatter = 'Votes per turnout for each candidate' +' in '+'#'+ region+'# scatter'
    
    # printing the plot
    print_multiply_plot(dataset_plot, x_column=x_column_plot, y_column=y_column_plot, 
              target_column=target_column, target_list=target_list, mult_type='in_one',
              grid=True, hight=hight_plot, weight=weight_plot, 
              need_legend=True, legend_fontsize=font_size_plot, 
              plot_name=plot_name_plot,
              need_xlim=True, xlim=100, xmin=0, need_ylim=True, ylim=ylim, ymin=0,
              need_label = True, ylabel=ylabel_plot, xlabel=xlabel_plot, need_print='Y',
              need_tick=True, tick_x=tick_x, tick_y=tick_y_plot)
    # and scatter
    print_multiply_scatter(dataset_scatter, x_column=x_column_scatter, y_column=y_column_scatter, 
              target_column=target_column, target_list=target_list, mult_type='in_one',
              grid=True, hight=hight_scatter, weight=weight_scatter, 
              need_legend=True, legend_fontsize=font_size_scatter, 
              plot_name=plot_name_scatter,
              need_xlim=True, xlim=100, xmin=0, need_ylim=True, ylim=100, ymin=0,
              need_label = True, ylabel=ylabel_scatter, xlabel=xlabel_scatter, need_print='Y',
              need_tick=False, tick_x=tick_x, tick_y=tick_y_scatter)
    
    print('____________________________', region,'________________________________________________________________________')
    
    #there is not interest information about election in foreign countries
    
```


    
![png](output_45_0.png)
    



    
![png](output_45_1.png)
    


    ____________________________ Вінницька область ________________________________________________________________________
    


    
![png](output_45_3.png)
    



    
![png](output_45_4.png)
    


    ____________________________ Волинська область ________________________________________________________________________
    


    
![png](output_45_6.png)
    



    
![png](output_45_7.png)
    


    ____________________________ Дніпропетровська область ________________________________________________________________________
    


    
![png](output_45_9.png)
    



    
![png](output_45_10.png)
    


    ____________________________ Донецька область ________________________________________________________________________
    


    
![png](output_45_12.png)
    



    
![png](output_45_13.png)
    


    ____________________________ Житомирська область ________________________________________________________________________
    


    
![png](output_45_15.png)
    



    
![png](output_45_16.png)
    


    ____________________________ Закарпатська область ________________________________________________________________________
    


    
![png](output_45_18.png)
    



    
![png](output_45_19.png)
    


    ____________________________ Запорізька область ________________________________________________________________________
    


    
![png](output_45_21.png)
    



    
![png](output_45_22.png)
    


    ____________________________ Івано-Франківська область ________________________________________________________________________
    


    
![png](output_45_24.png)
    



    
![png](output_45_25.png)
    


    ____________________________ Київська область ________________________________________________________________________
    


    
![png](output_45_27.png)
    



    
![png](output_45_28.png)
    


    ____________________________ Кіровоградська область ________________________________________________________________________
    


    
![png](output_45_30.png)
    



    
![png](output_45_31.png)
    


    ____________________________ Луганська область ________________________________________________________________________
    


    
![png](output_45_33.png)
    



    
![png](output_45_34.png)
    


    ____________________________ Львівська область ________________________________________________________________________
    


    
![png](output_45_36.png)
    



    
![png](output_45_37.png)
    


    ____________________________ Миколаївська область ________________________________________________________________________
    


    
![png](output_45_39.png)
    



    
![png](output_45_40.png)
    


    ____________________________ Одеська область ________________________________________________________________________
    


    
![png](output_45_42.png)
    



    
![png](output_45_43.png)
    


    ____________________________ Полтавська область ________________________________________________________________________
    


    
![png](output_45_45.png)
    



    
![png](output_45_46.png)
    


    ____________________________ Рівненська область ________________________________________________________________________
    


    
![png](output_45_48.png)
    



    
![png](output_45_49.png)
    


    ____________________________ Сумська область ________________________________________________________________________
    


    
![png](output_45_51.png)
    



    
![png](output_45_52.png)
    


    ____________________________ Тернопільська область ________________________________________________________________________
    


    
![png](output_45_54.png)
    



    
![png](output_45_55.png)
    


    ____________________________ Харківська область ________________________________________________________________________
    


    
![png](output_45_57.png)
    



    
![png](output_45_58.png)
    


    ____________________________ Херсонська область ________________________________________________________________________
    


    
![png](output_45_60.png)
    



    
![png](output_45_61.png)
    


    ____________________________ Хмельницька область ________________________________________________________________________
    


    
![png](output_45_63.png)
    



    
![png](output_45_64.png)
    


    ____________________________ Черкаська область ________________________________________________________________________
    


    
![png](output_45_66.png)
    



    
![png](output_45_67.png)
    


    ____________________________ Чернівецька область ________________________________________________________________________
    


    
![png](output_45_69.png)
    



    
![png](output_45_70.png)
    


    ____________________________ Чернігівська область ________________________________________________________________________
    


    
![png](output_45_72.png)
    



    
![png](output_45_73.png)
    


    ____________________________ м. Київ ________________________________________________________________________
    

#### Check the relationship between Gricenko and Smeshko


```python
# make a sample with Smeshko and Gricenko 
gricenko_smeshko_sample_plot = results_total_joined[(results_total_joined['candidate'] == 'Гриценко Анатолій Степанович') | 
                                               (results_total_joined['candidate'] == 'Смешко Ігор Петрович')]
gricenko_smeshko_sample_plot
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>votes_candidates</th>
      <th>voted_total_percent_rounded</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>269901</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50130</td>
      <td>73</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>959648</th>
      <td>Смешко Ігор Петрович</td>
      <td>11</td>
      <td>50130</td>
      <td>120</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>269902</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50131</td>
      <td>97</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1341</td>
      <td>64.0</td>
    </tr>
    <tr>
      <th>959649</th>
      <td>Смешко Ігор Петрович</td>
      <td>11</td>
      <td>50131</td>
      <td>147</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1341</td>
      <td>64.0</td>
    </tr>
    <tr>
      <th>269903</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50132</td>
      <td>48</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>822</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>989634</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900123</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59</td>
      <td>65.0</td>
    </tr>
    <tr>
      <th>299888</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>226</td>
      <td>900124</td>
      <td>9</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>122</td>
      <td>77.0</td>
    </tr>
    <tr>
      <th>989635</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900124</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>122</td>
      <td>77.0</td>
    </tr>
    <tr>
      <th>299889</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>226</td>
      <td>900125</td>
      <td>34</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>989636</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900125</td>
      <td>10</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.0</td>
    </tr>
  </tbody>
</table>
<p>59978 rows × 9 columns</p>
</div>




```python
# dividing data per sample with gricenko and smeshko
gricenko_data = results_total[(results_total['candidate'] == 'Гриценко Анатолій Степанович')]
smeshko_data = results_total[(results_total['candidate'] == 'Смешко Ігор Петрович')]
smeshko_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>votes_candidates</th>
      <th>voted_total_percent</th>
      <th>candidate_percent_per_precint</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>959648</th>
      <td>Смешко Ігор Петрович</td>
      <td>11</td>
      <td>50130</td>
      <td>120</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.48</td>
      <td>10.899183</td>
    </tr>
    <tr>
      <th>959649</th>
      <td>Смешко Ігор Петрович</td>
      <td>11</td>
      <td>50131</td>
      <td>147</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1341</td>
      <td>64.39</td>
      <td>10.961969</td>
    </tr>
    <tr>
      <th>959650</th>
      <td>Смешко Ігор Петрович</td>
      <td>11</td>
      <td>50132</td>
      <td>95</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>822</td>
      <td>65.60</td>
      <td>11.557178</td>
    </tr>
    <tr>
      <th>959651</th>
      <td>Смешко Ігор Петрович</td>
      <td>11</td>
      <td>50133</td>
      <td>186</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1583</td>
      <td>65.48</td>
      <td>11.749842</td>
    </tr>
    <tr>
      <th>959652</th>
      <td>Смешко Ігор Петрович</td>
      <td>11</td>
      <td>50134</td>
      <td>14</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>140</td>
      <td>62.22</td>
      <td>10.000000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>989632</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900121</td>
      <td>60</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>540</td>
      <td>13.02</td>
      <td>11.111111</td>
    </tr>
    <tr>
      <th>989633</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900122</td>
      <td>111</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1434</td>
      <td>6.79</td>
      <td>7.740586</td>
    </tr>
    <tr>
      <th>989634</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900123</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59</td>
      <td>64.83</td>
      <td>10.169492</td>
    </tr>
    <tr>
      <th>989635</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900124</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>122</td>
      <td>77.21</td>
      <td>4.918033</td>
    </tr>
    <tr>
      <th>989636</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900125</td>
      <td>10</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.27</td>
      <td>4.310345</td>
    </tr>
  </tbody>
</table>
<p>29989 rows × 10 columns</p>
</div>




```python
# creating new dataframe gricenko_smeshko_corr which contain percents of votes in precint per smeshko and gricenko
gricenko_smeshko_corr = smeshko_data.drop(columns=['candidate', 'votes_candidates']).reset_index(drop=True)
gricenko_smeshko_corr['gricenko_percent'] = gricenko_data['candidate_percent_per_precint'].reset_index(drop=True)
gricenko_smeshko_corr['smeshko_percent'] = smeshko_data['candidate_percent_per_precint'].reset_index(drop=True)

# see the correlation
correlation_value = gricenko_smeshko_corr['gricenko_percent'].corr(gricenko_smeshko_corr['smeshko_percent'])
correlation_value = 'corr = ' + str(np.round(correlation_value, 3))

# target column s necessary fr using my functions for printing the scatter and it is printe the value from it
gricenko_smeshko_corr['target'] = correlation_value

gricenko_smeshko_corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>voted_total_percent</th>
      <th>candidate_percent_per_precint</th>
      <th>gricenko_percent</th>
      <th>smeshko_percent</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>11</td>
      <td>50130</td>
      <td>120</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>66.48</td>
      <td>10.899183</td>
      <td>6.630336</td>
      <td>10.899183</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>1</th>
      <td>11</td>
      <td>50131</td>
      <td>147</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>64.39</td>
      <td>10.961969</td>
      <td>7.233408</td>
      <td>10.961969</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>2</th>
      <td>11</td>
      <td>50132</td>
      <td>95</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>65.60</td>
      <td>11.557178</td>
      <td>5.839416</td>
      <td>11.557178</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11</td>
      <td>50133</td>
      <td>186</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>65.48</td>
      <td>11.749842</td>
      <td>5.938092</td>
      <td>11.749842</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>4</th>
      <td>11</td>
      <td>50134</td>
      <td>14</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>62.22</td>
      <td>10.000000</td>
      <td>8.571429</td>
      <td>10.000000</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>29984</th>
      <td>226</td>
      <td>900121</td>
      <td>60</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>13.02</td>
      <td>11.111111</td>
      <td>14.444444</td>
      <td>11.111111</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>29985</th>
      <td>226</td>
      <td>900122</td>
      <td>111</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6.79</td>
      <td>7.740586</td>
      <td>6.624826</td>
      <td>7.740586</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>29986</th>
      <td>226</td>
      <td>900123</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>64.83</td>
      <td>10.169492</td>
      <td>10.169492</td>
      <td>10.169492</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>29987</th>
      <td>226</td>
      <td>900124</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>77.21</td>
      <td>4.918033</td>
      <td>7.377049</td>
      <td>4.918033</td>
      <td>corr = 0.155</td>
    </tr>
    <tr>
      <th>29988</th>
      <td>226</td>
      <td>900125</td>
      <td>10</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>26.27</td>
      <td>4.310345</td>
      <td>14.655172</td>
      <td>4.310345</td>
      <td>corr = 0.155</td>
    </tr>
  </tbody>
</table>
<p>29989 rows × 11 columns</p>
</div>




```python
# common variables
xmin, xlim = 0, 100
 # ticks
tick_x = 5
tick_y = 5

target_column = 'target'
target_list = [correlation_value]

# variables for scatter
weight_scatter, hight_scatter = 6 , 6
font_size_scatter = 7

xlabel_scatter = 'gricenko votes in %'
ylabel_scatter = 'smeshko votes in %'
x_column_scatter = 'gricenko_percent'
y_column_scatter = 'smeshko_percent'

plot_name = 'scatter of percents of votes per each candidates'

# printing the scatter of correlations
print_multiply_scatter(gricenko_smeshko_corr, x_column=x_column_scatter, y_column=y_column_scatter, 
              target_column=target_column, target_list=target_list, mult_type='in_one',
              grid=True, hight=hight_scatter, weight=weight_scatter, 
              need_legend=True, legend_fontsize=font_size_scatter,
              plot_name=plot_name,
              need_xlim=True, xlim=30, xmin=0.01, need_ylim=True, ylim=30, ymin=0,
              need_label=True, ylabel=ylabel_scatter, xlabel=xlabel_scatter,
              need_tick=True, tick_x=tick_x, tick_y=tick_y) 
```


    
![png](output_50_0.png)
    



```python
# list in which values about region and corr_value per region will be contained 
region_list = []
corr_val_list = []

# walking into ukrainian regions and counting the correlation for Gricenko/Smeshko relationship
for region in gricenko_smeshko_corr['region'].unique():
    gricenko_smeshko_regional_corr = gricenko_smeshko_corr[gricenko_smeshko_corr['region'] == region]
    correlation_value = gricenko_smeshko_regional_corr['gricenko_percent'].corr(
                        gricenko_smeshko_regional_corr['smeshko_percent'])
    correlation_value_str = 'corr = ' + str(np.round(correlation_value, 3))
    
    # adding new values to list
    region_list.append(region)
    corr_val_list.append(correlation_value)
    
# creating dataframe which contains regions and their correlation values
region_corr_tab = pd.DataFrame(columns=['region', 'correlation_value'], 
                               index=[i for i in range(len(region_list))])
region_corr_tab['region'] = pd.Series(region_list)
region_corr_tab['correlation_value'] = pd.Series(corr_val_list)

region_corr_tab
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>region</th>
      <th>correlation_value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Вінницька область</td>
      <td>0.309552</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Волинська область</td>
      <td>0.414182</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Дніпропетровська область</td>
      <td>0.327999</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Донецька область</td>
      <td>0.366323</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Житомирська область</td>
      <td>0.233900</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Закарпатська область</td>
      <td>0.603844</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Запорізька область</td>
      <td>0.415657</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Івано-Франківська область</td>
      <td>0.275522</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Київська область</td>
      <td>0.143228</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Кіровоградська область</td>
      <td>0.363869</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Луганська область</td>
      <td>0.236465</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Львівська область</td>
      <td>0.078061</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Миколаївська область</td>
      <td>0.239684</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Одеська область</td>
      <td>0.188261</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Полтавська область</td>
      <td>0.266667</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Рівненська область</td>
      <td>0.488893</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Сумська область</td>
      <td>0.351430</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Тернопільська область</td>
      <td>0.343358</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Харківська область</td>
      <td>0.436745</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Херсонська область</td>
      <td>0.253399</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Хмельницька область</td>
      <td>0.270736</td>
    </tr>
    <tr>
      <th>21</th>
      <td>Черкаська область</td>
      <td>-0.027995</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Чернівецька область</td>
      <td>0.587020</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Чернігівська область</td>
      <td>0.081151</td>
    </tr>
    <tr>
      <th>24</th>
      <td>м. Київ</td>
      <td>0.108438</td>
    </tr>
    <tr>
      <th>25</th>
      <td>За межами України</td>
      <td>0.304229</td>
    </tr>
  </tbody>
</table>
</div>




```python
# for region in gricenko_smeshko_corr['region'].unique():
#     print(gricenko_smeshko_corr[gricenko_smeshko_corr['region']==region][['region', 'gricenko_percent', 'smeshko_percent']])

region_corr_tab[region_corr_tab['region'] == region]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>region</th>
      <th>correlation_value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>25</th>
      <td>За межами України</td>
      <td>0.304229</td>
    </tr>
  </tbody>
</table>
</div>




```python
# common variables
xmin, xlim = 0, 100
 # ticks
tick_x = 5
tick_y = 5

target_column = 'target'

# variables for scatter
weight_scatter, hight_scatter = 7 , 7
font_size_scatter = 7

xlabel_scatter = 'gricenko votes in %'
ylabel_scatter = 'smeshko votes in %'
x_column_scatter = 'gricenko_percent'
y_column_scatter = 'smeshko_percent'

plot_name = 'scatter of percents of votes per each candidates'

for region in gricenko_smeshko_corr['region'].unique():
    correlation_value = 'corr= '+ str(np.round(float(region_corr_tab[region_corr_tab['region'] == region].values[[0],[1]]), 3))
    gricenko_smeshko_region_df = gricenko_smeshko_corr[gricenko_smeshko_corr['region'] == region].drop('target', axis=1)
    gricenko_smeshko_region_df['target'] = correlation_value
    target_list = [correlation_value]
    
    # scatter var
    xlim = gricenko_smeshko_region_df['gricenko_percent'].quantile(0.995, interpolation = 'linear')
    ylim = gricenko_smeshko_region_df['smeshko_percent'].quantile(0.995, interpolation = 'linear')
    
    print_multiply_scatter(gricenko_smeshko_region_df, 
            x_column=x_column_scatter, y_column=y_column_scatter, 
              target_column=target_column, target_list=[correlation_value], mult_type='in_one',
              grid=True, hight=hight_scatter, weight=weight_scatter, 
              need_legend=True, legend_fontsize=font_size_scatter,
              plot_name=plot_name+' in '+str(region),
              need_xlim=True, xlim=xlim, xmin=0.01, need_ylim=True, ylim=ylim, ymin=0,
              need_label=True, ylabel=ylabel_scatter, xlabel=xlabel_scatter, need_print='Y',
              need_tick=True, tick_x=tick_x, tick_y=tick_y) 

```


    
![png](output_53_0.png)
    



    
![png](output_53_1.png)
    



    
![png](output_53_2.png)
    



    
![png](output_53_3.png)
    



    
![png](output_53_4.png)
    



    
![png](output_53_5.png)
    



    
![png](output_53_6.png)
    



    
![png](output_53_7.png)
    



    
![png](output_53_8.png)
    



    
![png](output_53_9.png)
    



    
![png](output_53_10.png)
    



    
![png](output_53_11.png)
    



    
![png](output_53_12.png)
    



    
![png](output_53_13.png)
    



    
![png](output_53_14.png)
    



    
![png](output_53_15.png)
    



    
![png](output_53_16.png)
    



    
![png](output_53_17.png)
    



    
![png](output_53_18.png)
    



    
![png](output_53_19.png)
    



    
![png](output_53_20.png)
    



    
![png](output_53_21.png)
    



    
![png](output_53_22.png)
    



    
![png](output_53_23.png)
    



    
![png](output_53_24.png)
    



    
![png](output_53_25.png)
    



```python
gricenko_smeshko_region_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>voted_total_percent</th>
      <th>candidate_percent_per_precint</th>
      <th>gricenko_percent</th>
      <th>smeshko_percent</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>29888</th>
      <td>226</td>
      <td>900001</td>
      <td>3</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>7.19</td>
      <td>2.400000</td>
      <td>15.200000</td>
      <td>2.400000</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29889</th>
      <td>226</td>
      <td>900002</td>
      <td>60</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>39.30</td>
      <td>6.335797</td>
      <td>15.522703</td>
      <td>6.335797</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29890</th>
      <td>226</td>
      <td>900003</td>
      <td>4</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>61.40</td>
      <td>2.285714</td>
      <td>10.285714</td>
      <td>2.285714</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29891</th>
      <td>226</td>
      <td>900004</td>
      <td>5</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>22.41</td>
      <td>7.692308</td>
      <td>0.000000</td>
      <td>7.692308</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29892</th>
      <td>226</td>
      <td>900005</td>
      <td>23</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>18.66</td>
      <td>11.794872</td>
      <td>6.153846</td>
      <td>11.794872</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>29984</th>
      <td>226</td>
      <td>900121</td>
      <td>60</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>13.02</td>
      <td>11.111111</td>
      <td>14.444444</td>
      <td>11.111111</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29985</th>
      <td>226</td>
      <td>900122</td>
      <td>111</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6.79</td>
      <td>7.740586</td>
      <td>6.624826</td>
      <td>7.740586</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29986</th>
      <td>226</td>
      <td>900123</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>64.83</td>
      <td>10.169492</td>
      <td>10.169492</td>
      <td>10.169492</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29987</th>
      <td>226</td>
      <td>900124</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>77.21</td>
      <td>4.918033</td>
      <td>7.377049</td>
      <td>4.918033</td>
      <td>corr= 0.304</td>
    </tr>
    <tr>
      <th>29988</th>
      <td>226</td>
      <td>900125</td>
      <td>10</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>26.27</td>
      <td>4.310345</td>
      <td>14.655172</td>
      <td>4.310345</td>
      <td>corr= 0.304</td>
    </tr>
  </tbody>
</table>
<p>101 rows × 11 columns</p>
</div>




```python
gricenko_smeshko_sample_scatter = results_total[(results_total['candidate'] == 'Гриценко Анатолій Степанович') | 
                                                (results_total['candidate'] == 'Смешко Ігор Петрович')]
gricenko_smeshko_sample_scatter
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>candidate</th>
      <th>district_no</th>
      <th>precinct_no</th>
      <th>vote_count</th>
      <th>region</th>
      <th>rayon</th>
      <th>community</th>
      <th>votes_candidates</th>
      <th>voted_total_percent</th>
      <th>candidate_percent_per_precint</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>269901</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50130</td>
      <td>73</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1101</td>
      <td>66.48</td>
      <td>6.630336</td>
    </tr>
    <tr>
      <th>269902</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50131</td>
      <td>97</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1341</td>
      <td>64.39</td>
      <td>7.233408</td>
    </tr>
    <tr>
      <th>269903</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50132</td>
      <td>48</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>822</td>
      <td>65.60</td>
      <td>5.839416</td>
    </tr>
    <tr>
      <th>269904</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50133</td>
      <td>94</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>1583</td>
      <td>65.48</td>
      <td>5.938092</td>
    </tr>
    <tr>
      <th>269905</th>
      <td>Гриценко Анатолій Степанович</td>
      <td>11</td>
      <td>50134</td>
      <td>12</td>
      <td>Вінницька область</td>
      <td>Вінницький район</td>
      <td>Стрижавська селищна рада</td>
      <td>140</td>
      <td>62.22</td>
      <td>8.571429</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>989632</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900121</td>
      <td>60</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>540</td>
      <td>13.02</td>
      <td>11.111111</td>
    </tr>
    <tr>
      <th>989633</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900122</td>
      <td>111</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1434</td>
      <td>6.79</td>
      <td>7.740586</td>
    </tr>
    <tr>
      <th>989634</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900123</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>59</td>
      <td>64.83</td>
      <td>10.169492</td>
    </tr>
    <tr>
      <th>989635</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900124</td>
      <td>6</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>122</td>
      <td>77.21</td>
      <td>4.918033</td>
    </tr>
    <tr>
      <th>989636</th>
      <td>Смешко Ігор Петрович</td>
      <td>226</td>
      <td>900125</td>
      <td>10</td>
      <td>За межами України</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>232</td>
      <td>26.27</td>
      <td>4.310345</td>
    </tr>
  </tbody>
</table>
<p>59978 rows × 10 columns</p>
</div>



#### Printing the scatter of percent of votes in precint per turnout in summary for 


```python
# prnting the percent's distribution for every candidate in one scatter
print_multiply_scatter(gricenko_smeshko_sample_scatter, x_column='voted_total_percent', y_column='candidate_percent_per_precint', 
              target_column='candidate', target_list=['Смешко Ігор Петрович','Гриценко Анатолій Степанович'], mult_type='in_one',
              grid=True, hight=7, weight=7, 
              need_legend=True, legend_fontsize=7,
              plot_name='Percent of votes in precint per turnout',
              need_xlim=True, xlim=101, xmin=0, need_ylim=True, ylim=101, ymin=0,
              need_label=True, ylabel='percent of votes in percint', xlabel='turnout in %',
              need_tick=True, tick_x=5, tick_y=5)  
```


    
![png](output_57_0.png)
    


# Summary

1. The distribution of distribution of votes per turnout in precints is normal. The are no outliers in right side of plot. The first tour of presidental elections is fair
2. Per regions, there were no extremal turnouts for one candidate (in power).
3. Information that Smeshko was technical candidate for deriving votes from Gricenko is not proof in statisitical sense. There was not strong correlation between two candidates. Per regions, only Zakarpatska gives a correlation more than 0.5.
